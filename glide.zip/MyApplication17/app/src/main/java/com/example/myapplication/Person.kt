package com.example.myapplication

data class Person (
    val imageUrl:String,
    val title:String,
    val description:String

)